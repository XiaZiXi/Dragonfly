Dragonfly.

Source files are all in the Source folder.
Include files are all in the Include folder.

Expects the SFML folder to be up one level from this folder.

To run, use the Local Windows Debugger in Visual Studio.

The demo program shows three objects on the screen.
	The first is a boundary along the bottom. It is meant to show all of the different characters that can be drawn.
	The second is a fast moving object which moves around the periphery of the window. It collides with the boundary and changes trajectory.
	The third is a SOFT object which floats around the screen and can be controlled with the spacebar and left mouse clicks.