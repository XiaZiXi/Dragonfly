Dragonfly.

Source files are all in the Source folder.
	There is a subfolder Saucer Shoot which contains the source files for Saucer Shoot.
Include files are all in the Include folder.
	There is a subfolder Saucer Shoot which contains the header files for Saucer Shoot.

Expects the SFML folder to be up one level from this directory.

To run, use the Local Windows Debugger in Visual Studio.
Run in Debug.

Starts up the Saucer Shoot game.