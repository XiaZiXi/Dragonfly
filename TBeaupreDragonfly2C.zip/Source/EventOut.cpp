#include "EventOut.h"

df::EventOut::EventOut()
{
	setType(OUT_EVENT);
}
