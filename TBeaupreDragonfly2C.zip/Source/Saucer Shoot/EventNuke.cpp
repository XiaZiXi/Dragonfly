//
// EventNuke.cpp
//

#include "EventNuke.h"

EventNuke::EventNuke() {
  setType(NUKE_EVENT);
};
