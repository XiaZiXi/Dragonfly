#pragma once

namespace df {

// Set of mouse actions recognized by Dragonfly.
enum MouseAction {
	UNDEFINED_MOUSE_ACTION = -1,
	CLICKED,
	PRESSED,
	MOVED
};
}