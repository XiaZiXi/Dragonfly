#pragma once

namespace df {
enum Solidness {
	HARD,
	SOFT,
	SPECTRAL
};
}